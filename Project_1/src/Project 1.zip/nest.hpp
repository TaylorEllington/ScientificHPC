#ifndef _NESTEDMULTI_
#define _NESTEDMULTI_

#include "matrix.hpp"

double nest(const Matrix& a , double x);

#endif