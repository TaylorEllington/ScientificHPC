#pragma once 
class Fcn{
	public:

	virtual double operator() (double x) = 0;
};